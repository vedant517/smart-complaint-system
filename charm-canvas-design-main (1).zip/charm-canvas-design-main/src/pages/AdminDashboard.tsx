import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, PieChart, Pie, Cell, LineChart, Line, AreaChart, Area, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown, Users, FileText, Clock, CheckCircle, AlertTriangle, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

// Mock data for charts
const monthlyComplaints = [
  { month: "Jan", total: 45, resolved: 38, pending: 7 },
  { month: "Feb", total: 52, resolved: 44, pending: 8 },
  { month: "Mar", total: 61, resolved: 53, pending: 8 },
  { month: "Apr", total: 48, resolved: 42, pending: 6 },
  { month: "May", total: 73, resolved: 65, pending: 8 },
  { month: "Jun", total: 89, resolved: 78, pending: 11 },
];

const categoryData = [
  { name: "Infrastructure", value: 35, fill: "hsl(175 70% 35%)" },
  { name: "Sanitation", value: 25, fill: "hsl(220 60% 35%)" },
  { name: "Water Supply", value: 20, fill: "hsl(158 64% 40%)" },
  { name: "Electricity", value: 12, fill: "hsl(38 92% 50%)" },
  { name: "Other", value: 8, fill: "hsl(220 14% 50%)" },
];

const resolutionTimeData = [
  { day: "Mon", avgHours: 24 },
  { day: "Tue", avgHours: 18 },
  { day: "Wed", avgHours: 32 },
  { day: "Thu", avgHours: 22 },
  { day: "Fri", avgHours: 28 },
  { day: "Sat", avgHours: 36 },
  { day: "Sun", avgHours: 42 },
];

const officerData = [
  { name: "John Smith", assigned: 28, resolved: 24, pending: 4 },
  { name: "Sarah Johnson", assigned: 32, resolved: 30, pending: 2 },
  { name: "Mike Chen", assigned: 25, resolved: 20, pending: 5 },
  { name: "Emily Davis", assigned: 30, resolved: 28, pending: 2 },
  { name: "Alex Wilson", assigned: 22, resolved: 18, pending: 4 },
];

const chartConfig = {
  total: { label: "Total", color: "hsl(220 60% 35%)" },
  resolved: { label: "Resolved", color: "hsl(158 64% 40%)" },
  pending: { label: "Pending", color: "hsl(38 92% 50%)" },
  assigned: { label: "Assigned", color: "hsl(220 60% 35%)" },
  avgHours: { label: "Avg Hours", color: "hsl(175 70% 35%)" },
};

const StatCard = ({ title, value, change, changeType, icon: Icon, iconBg }: {
  title: string;
  value: string | number;
  change: string;
  changeType: "up" | "down";
  icon: React.ElementType;
  iconBg: string;
}) => (
  <Card className="hover-lift">
    <CardContent className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground font-medium">{title}</p>
          <p className="text-3xl font-bold mt-1">{value}</p>
          <div className={`flex items-center gap-1 mt-2 text-sm ${changeType === "up" ? "text-success" : "text-destructive"}`}>
            {changeType === "up" ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            <span>{change}</span>
          </div>
        </div>
        <div className={`w-14 h-14 rounded-2xl ${iconBg} flex items-center justify-center`}>
          <Icon className="w-7 h-7 text-primary-foreground" />
        </div>
      </div>
    </CardContent>
  </Card>
);

const AdminDashboard = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back
                </Button>
              </Link>
              <div className="h-8 w-px bg-border" />
              <h1 className="text-xl font-bold">Admin Dashboard</h1>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sm text-muted-foreground">Last updated: Just now</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Complaints"
            value={368}
            change="+12% from last month"
            changeType="up"
            icon={FileText}
            iconBg="bg-primary"
          />
          <StatCard
            title="Resolved"
            value={300}
            change="+8% from last month"
            changeType="up"
            icon={CheckCircle}
            iconBg="bg-success"
          />
          <StatCard
            title="Pending"
            value={68}
            change="-5% from last month"
            changeType="down"
            icon={AlertTriangle}
            iconBg="bg-warning"
          />
          <StatCard
            title="Active Officers"
            value={12}
            change="+2 new this month"
            changeType="up"
            icon={Users}
            iconBg="bg-accent"
          />
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Monthly Complaints Trend */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-accent" />
                Monthly Complaint Trend
              </CardTitle>
              <CardDescription>Overview of complaints over the past 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer config={chartConfig} className="h-[300px]">
                <BarChart data={monthlyComplaints}>
                  <XAxis dataKey="month" tickLine={false} axisLine={false} />
                  <YAxis tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <ChartLegend content={<ChartLegendContent />} />
                  <Bar dataKey="resolved" fill="hsl(158 64% 40%)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="pending" fill="hsl(38 92% 50%)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Category Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-accent" />
                Category Breakdown
              </CardTitle>
              <CardDescription>Distribution of complaints by category</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer config={chartConfig} className="h-[300px]">
                <PieChart>
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Pie
                    data={categoryData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    innerRadius={60}
                    paddingAngle={2}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                </PieChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Resolution Time */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-accent" />
                Average Resolution Time
              </CardTitle>
              <CardDescription>Average hours to resolve complaints by day</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer config={chartConfig} className="h-[300px]">
                <AreaChart data={resolutionTimeData}>
                  <defs>
                    <linearGradient id="colorAvgHours" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(175 70% 35%)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(175 70% 35%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="day" tickLine={false} axisLine={false} />
                  <YAxis tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area
                    type="monotone"
                    dataKey="avgHours"
                    stroke="hsl(175 70% 35%)"
                    strokeWidth={2}
                    fill="url(#colorAvgHours)"
                  />
                </AreaChart>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Officer Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-accent" />
                Officer Assignments
              </CardTitle>
              <CardDescription>Complaint distribution and resolution by officer</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer config={chartConfig} className="h-[300px]">
                <BarChart data={officerData} layout="vertical">
                  <XAxis type="number" tickLine={false} axisLine={false} />
                  <YAxis dataKey="name" type="category" tickLine={false} axisLine={false} width={100} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <ChartLegend content={<ChartLegendContent />} />
                  <Bar dataKey="resolved" fill="hsl(158 64% 40%)" radius={[0, 4, 4, 0]} stackId="a" />
                  <Bar dataKey="pending" fill="hsl(38 92% 50%)" radius={[0, 4, 4, 0]} stackId="a" />
                </BarChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity Table */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Complaint Activity</CardTitle>
            <CardDescription>Latest complaints and their current status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">ID</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">Category</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">Submitted</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">Assigned To</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { id: "CMP-001", category: "Infrastructure", date: "Dec 30, 2025", officer: "John Smith", status: "In Progress" },
                    { id: "CMP-002", category: "Sanitation", date: "Dec 29, 2025", officer: "Sarah Johnson", status: "Resolved" },
                    { id: "CMP-003", category: "Water Supply", date: "Dec 29, 2025", officer: "Mike Chen", status: "Pending" },
                    { id: "CMP-004", category: "Electricity", date: "Dec 28, 2025", officer: "Emily Davis", status: "Resolved" },
                    { id: "CMP-005", category: "Infrastructure", date: "Dec 28, 2025", officer: "Alex Wilson", status: "In Progress" },
                  ].map((complaint) => (
                    <tr key={complaint.id} className="border-b border-border/50 hover:bg-muted/50 transition-colors">
                      <td className="py-3 px-4 font-mono text-sm font-medium">{complaint.id}</td>
                      <td className="py-3 px-4 text-sm">{complaint.category}</td>
                      <td className="py-3 px-4 text-sm text-muted-foreground">{complaint.date}</td>
                      <td className="py-3 px-4 text-sm">{complaint.officer}</td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                          complaint.status === "Resolved" 
                            ? "bg-success/10 text-success" 
                            : complaint.status === "In Progress"
                            ? "bg-accent/10 text-accent"
                            : "bg-warning/10 text-warning"
                        }`}>
                          {complaint.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default AdminDashboard;
