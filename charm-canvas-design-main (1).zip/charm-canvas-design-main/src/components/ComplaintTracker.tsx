import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Clock, CheckCircle2, AlertCircle, ArrowRight, Calendar, MapPin, Tag } from "lucide-react";

interface Complaint {
  id: string;
  title: string;
  category: string;
  location: string;
  date: string;
  status: "pending" | "in-progress" | "resolved";
  statusText: string;
  progress: number;
}

const ComplaintTracker = () => {
  const [trackingId, setTrackingId] = useState("");
  const [isSearching, setIsSearching] = useState(false);

  // Sample complaints for demo
  const sampleComplaints: Complaint[] = [
    {
      id: "#SC-2024-001234",
      title: "Pothole on Main Street",
      category: "Infrastructure & Roads",
      location: "123 Main Street, Downtown",
      date: "Dec 28, 2024",
      status: "in-progress",
      statusText: "Under Review",
      progress: 60,
    },
    {
      id: "#SC-2024-001189",
      title: "Street Light Not Working",
      category: "Utilities",
      location: "Oak Avenue & 5th Street",
      date: "Dec 25, 2024",
      status: "resolved",
      statusText: "Resolved",
      progress: 100,
    },
    {
      id: "#SC-2024-001156",
      title: "Garbage Collection Delay",
      category: "Sanitation & Waste",
      location: "Maple Drive, Sector 7",
      date: "Dec 22, 2024",
      status: "pending",
      statusText: "Submitted",
      progress: 20,
    },
  ];

  const getStatusColor = (status: Complaint["status"]) => {
    switch (status) {
      case "resolved":
        return "bg-success/10 text-success border-success/20";
      case "in-progress":
        return "bg-warning/10 text-warning border-warning/20";
      case "pending":
        return "bg-pending/10 text-pending border-pending/20";
    }
  };

  const getStatusIcon = (status: Complaint["status"]) => {
    switch (status) {
      case "resolved":
        return CheckCircle2;
      case "in-progress":
        return Clock;
      case "pending":
        return AlertCircle;
    }
  };

  const getProgressColor = (status: Complaint["status"]) => {
    switch (status) {
      case "resolved":
        return "bg-success";
      case "in-progress":
        return "bg-warning";
      case "pending":
        return "bg-pending";
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearching(true);
    await new Promise((resolve) => setTimeout(resolve, 800));
    setIsSearching(false);
  };

  return (
    <section id="track" className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
              <Search className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Track Status</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Track Your Complaints
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Enter your tracking ID to check the status of your complaint, or browse your recent submissions.
            </p>
          </div>

          {/* Search Box */}
          <div className="bg-card rounded-2xl p-6 shadow-card border border-border mb-8">
            <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  value={trackingId}
                  onChange={(e) => setTrackingId(e.target.value)}
                  placeholder="Enter tracking ID (e.g., #SC-2024-001234)"
                  className="h-14 pl-12 text-base"
                />
              </div>
              <Button type="submit" variant="accent" size="lg" className="h-14 px-8" disabled={isSearching}>
                {isSearching ? "Searching..." : "Track"}
                <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </form>
          </div>

          {/* Recent Complaints */}
          <div className="space-y-4">
            <h3 className="font-display text-xl font-semibold text-foreground mb-6">
              Recent Complaints
            </h3>
            
            {sampleComplaints.map((complaint) => {
              const StatusIcon = getStatusIcon(complaint.status);
              
              return (
                <div
                  key={complaint.id}
                  className="bg-card rounded-2xl p-6 shadow-card border border-border hover-lift cursor-pointer group"
                >
                  <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                    {/* Main Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start gap-3 mb-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${getStatusColor(complaint.status)}`}>
                          <StatusIcon className="w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap mb-1">
                            <span className="text-sm font-medium text-accent">{complaint.id}</span>
                            <span className={`text-xs px-2 py-0.5 rounded-full border ${getStatusColor(complaint.status)}`}>
                              {complaint.statusText}
                            </span>
                          </div>
                          <h4 className="font-semibold text-foreground truncate">{complaint.title}</h4>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground ml-13">
                        <span className="flex items-center gap-1.5">
                          <Tag className="w-3.5 h-3.5" />
                          {complaint.category}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5" />
                          {complaint.location}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5" />
                          {complaint.date}
                        </span>
                      </div>
                    </div>

                    {/* Progress */}
                    <div className="lg:w-48 flex-shrink-0">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-muted-foreground">Progress</span>
                        <span className="text-sm font-medium text-foreground">{complaint.progress}%</span>
                      </div>
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${getProgressColor(complaint.status)}`}
                          style={{ width: `${complaint.progress}%` }}
                        />
                      </div>
                    </div>

                    {/* Action */}
                    <Button variant="ghost" size="sm" className="self-start lg:self-center opacity-0 group-hover:opacity-100 transition-opacity">
                      View Details
                      <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ComplaintTracker;
